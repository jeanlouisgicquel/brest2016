package service;

import java.rmi.Remote;
import java.util.Date;
import java.rmi.RemoteException;

public interface IBanqueRemote extends Remote {
	public double conversion(double mt) throws RemoteException;
	public Date getServerDate() throws RemoteException;
}
